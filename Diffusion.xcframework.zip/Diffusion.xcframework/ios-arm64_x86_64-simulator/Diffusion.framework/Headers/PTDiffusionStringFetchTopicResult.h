//  Diffusion Client Library for iOS and OS X / macOS
//
//  Copyright (c) 2018 - 2026 DiffusionData Ltd., All Rights Reserved.
//
//  Use is subject to licence terms.
//
//  NOTICE: All information contained herein is, and remains the
//  property of DiffusionData. The intellectual and technical
//  concepts contained herein are proprietary to DiffusionData and
//  may be covered by U.S. and Foreign Patents, patents in process, and
//  are protected by trade secret or copyright law.

#import <Foundation/Foundation.h>
#import <Diffusion/PTDiffusionFetchTopicResult.h>

NS_ASSUME_NONNULL_BEGIN

/**
 @ingroup PublicAPI_FetchRequest
 @ingroup PublicAPI_TopicDatatypes_String

 @brief Encapsulates the result from a string fetch operation for a single
 selected topic.

 A string fetch operation is issued using the
 PTDiffusionFetchRequest#fetchStringValuesWithTopicSelectorExpression:completionHandler:
 method.

 @since 6.2
 */
@interface PTDiffusionStringFetchTopicResult : PTDiffusionFetchTopicResult

/**
 Returns the topic value, or `nil` if the topic has no value.

 @since 6.2
 */
@property(nonatomic, readonly, nullable) NSString* string;

@end

NS_ASSUME_NONNULL_END
